## v1.2.0 (November 3, 2015)
- update to MDL 1.0.6

## v1.1.9 (Septemeber 15, 2015)
- update to MDL 1.0.5
- remove sticky footer, broke fixed navigation

## v1.1.8 (Septemeber 15, 2015)
- sticky footer thanks to https://github.com/atais

## v1.1.7 (August 25, 2015)
- update to MDL 1.0.4

## v1.1.6 (August 17, 2015)
- GitHub theme updater (https://github.com/afragen/github-updater)

## v1.1.5 (July 27, 2015)
- update to 1.0.1
- 1.0.1 MDL new footer class names
- update bower

## v1.1.4 (July 17, 2015)
- nav partials

## v1.1.3 (July 17, 2015)
- theme hooks

## v1.1.2 (July 14, 2015)
- ribbon content padding
- default body color

## v1.1.1 (July 14, 2015)
- fix gulp task

## v1.1.0 (July 14, 2015)
- new ribbon page template
- moved around container classes for easier page templates
- gulp zip task
- minor code formatting

## v1.0.1 (July 12, 2015)
- WP Customizer support (pick primary and accent colors)
- remove sass link color

## v1.0.0 (July 11, 2015)
- initial commit